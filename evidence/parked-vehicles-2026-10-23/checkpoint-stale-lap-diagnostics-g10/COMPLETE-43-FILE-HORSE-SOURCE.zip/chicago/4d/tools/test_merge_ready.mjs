#!/usr/bin/env node
/**
 * test_merge_ready.mjs — the thing that merges a finished pull request, tested
 * in the states that actually kept this repository's queue from draining.
 *
 * WHY THIS EXISTS. On 2026-09-14 the PR lap was fixed twice — it could not SEE
 * its pull requests (GraphQL budget), then it gated for ~7 minutes per PR
 * against merges landing every few minutes — and after both fixes the queue
 * still did not drain, because NOTHING MERGED A FINISHED PULL REQUEST. Three
 * pieces each assumed one of the others did it:
 *
 *   pr-lap.sh header       "auto-merge does that once `gate` goes green"
 *   steward-janitor.yml    "`custom` merges through the lap plus auto-merge"
 *                          — while deliberately excluding `custom` from itself
 *   chicago-4d-bake.yml    the ONLY `gh pr merge --auto` in the repo, on bakes
 *
 * Measured the same day: #1327 and #1312 both merged with `auto_merge: off`.
 * Auto-merge was armed by hand or not at all.
 *
 * THE SCRIPT IS NOT COPIED HERE. Each case runs the REAL
 * `.github/steward/merge-ready.sh` with `gh` faked on PATH, so a change that
 * makes it merge something it should not fails here rather than on `dev`.
 */
import { mkdtempSync, mkdirSync, writeFileSync, chmodSync, rmSync, readFileSync, cpSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import path from 'node:path';

const SH = path.resolve(path.dirname(new URL(import.meta.url).pathname),
                        '..', '..', '..', '.github', 'steward', 'merge-ready.sh');

let failures = 0;
const check = (what, ok, detail) => {
  console.log(`  ${ok ? 'ok  ' : 'FAIL'}  ${what}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failures += 1;
};

/**
 * Run the real script against a fake `gh`.
 *  list      newline-separated PR numbers the list call answers with
 *  listExit  its exit status
 *  states    { "<n>": "clean" | "blocked" | ... } answered for each PR
 *  only      MERGE_ONLY
 *  dry       MERGE_DRY_RUN
 * Every `gh api -X PUT .../merge` is appended to a file the caller reads back,
 * because "did it merge?" is the only question that matters here.
 */
function run({ list = '', listExit = 0, states = {}, only = '', dry = '' }) {
  const box = mkdtempSync(path.join(tmpdir(), 'mergeready-'));
  const bin = path.join(box, 'bin');
  mkdirSync(bin, { recursive: true });
  const merges = path.join(box, 'merges.txt');
  // Resolve the fixed fixture responses here: the fake CLI needs no Node child.
  // Shell quoting keeps both case keys and response values literal.
  const quoteShell = (value) => "'" + String(value).replaceAll("'", "'\\''") + "'";
  const stateCases = Object.entries(states)
    .map(([number, state]) => `  ${quoteShell(number)}) printf '%s\\n' ${quoteShell(state)} ;;`)
    .join('\n');

  writeFileSync(path.join(bin, 'gh'), `#!/usr/bin/env bash
# the merge itself — recorded, never performed
for a in "$@"; do
  case "$a" in */merge) echo "$*" >> ${JSON.stringify(merges)}; exit 0 ;; esac
done
# the PR list
case "$*" in
  *"pulls?state=open"*)
    printf '%b' ${JSON.stringify(list)}
    exit ${listExit} ;;
esac
# a single PR's fields: which one is asked for is in the path
N=""
for a in "$@"; do
  case "$a" in
    repos/*/pulls/*) N="\${a##*/}" ;;
  esac
done
case "$*" in
  *".mergeable_state"*)
    case "$N" in
${stateCases}
      *) printf '%s\\n' 'unknown' ;;
    esac ;;
  *".head.sha"*)        echo "deadbeefdeadbeefdeadbeefdeadbeefdeadbeef" ;;
  *".title"*)           echo "a pull request" ;;
esac
exit 0
`);
  chmodSync(path.join(bin, 'gh'), 0o755);

  // THE REPOSITORY IS NAMED, and the environment names a STRANGER on purpose
  // (T-1656). The script no longer reads $GITHUB_REPOSITORY — a run drives these
  // from a chicago checkout inside a polecat-platform job, so the ambient name is
  // whoever started the process — so every assertion below now also stands as proof
  // that the argument wins and the environment is ignored. The refusal itself is
  // tested at the bottom of this file.
  // THE SCRIPT RUNS FROM A SANDBOX CHECKOUT, NOT FROM THIS ONE (T-2929). Before it
  // merges a `clean` PR it reads `lap/pr-<N>` through the ticket.mjs beside it, from
  // that checkout's origin — run in place, that is the real GitHub remote, and this
  // suite would depend on the network and on whoever holds a lap today. The sandbox
  // carries the REAL script and the REAL ticket.mjs over an empty bare origin, so every
  // lock reads free; test_pr_lap_lock.mjs is where the held, stale and unreadable
  // locks are exercised.
  const checkout = path.join(box, 'checkout');
  const origin = path.join(box, 'locks.git');
  spawnSync('git', ['init', '--quiet', '--bare', origin]);
  spawnSync('git', ['init', '--quiet', checkout]);
  spawnSync('git', ['-C', checkout, 'remote', 'add', 'origin', origin]);
  const copy = path.join(checkout, '.github', 'steward', 'merge-ready.sh');
  mkdirSync(path.dirname(copy), { recursive: true });
  mkdirSync(path.join(checkout, 'chicago', '4d', 'tools'), { recursive: true });
  cpSync(SH, copy);
  cpSync(path.join(path.dirname(SH), '..', '..', 'chicago', '4d', 'tools', 'ticket.mjs'),
         path.join(checkout, 'chicago', '4d', 'tools', 'ticket.mjs'));
  const r = spawnSync('bash', [copy, '--repo', 'kevinrhaas/chicago'], {
    cwd: box,
    encoding: 'utf8',
    env: { ...process.env, PATH: `${bin}:${process.env.PATH}`,
           GH_TOKEN: 'fake', MERGE_ONLY: only, MERGE_DRY_RUN: dry,
           GITHUB_REPOSITORY: 'kevinrhaas/polecat-platform' },
  });
  let did = '';
  try { did = readFileSync(merges, 'utf8'); } catch { did = ''; }
  rmSync(box, { recursive: true, force: true });
  return { code: r.status, out: `${r.stdout || ''}${r.stderr || ''}`, merges: did };
}

console.log('merge-ready.sh — merges what GitHub calls clean, and nothing else');

/* 1. THE WHOLE POINT. A clean PR is merged. */
{
  const r = run({ list: '1319\n', states: { 1319: 'clean' } });
  check('a `clean` PR is merged', /pulls\/1319\/merge/.test(r.merges), r.merges.trim() || 'nothing merged');
  check('…by squash, as every other merge in this repo is',
        /merge_method=squash/.test(r.merges));
  check('…with the head sha pinned, so a push mid-read loses the race',
        /sha=deadbeef/.test(r.merges));
  check('…and the run says so', /#1319 {2}MERGED/.test(r.out));
}

/* 2. THE STATE THAT MATTERS MOST: a PR mid-gate must NOT be merged. `blocked`
 *    is what every PR reads while its gate runs, which after a lap is all of
 *    them at once. Merging on `blocked` would ship ungated trees to `dev`. */
{
  const r = run({ list: '1315\n', states: { 1315: 'blocked' } });
  check('a `blocked` PR is NOT merged — its gate has not passed',
        r.merges === '', r.merges.trim());
  check('…and is reported as waiting rather than skipped in silence',
        /not green yet/.test(r.out));
}

/* 3. `dirty` is the lap's job, and merging it is not possible anyway. */
{
  const r = run({ list: '1268\n', states: { 1268: 'dirty' } });
  check('a `dirty` PR is left for the lap', r.merges === '', r.merges.trim());
  check('…and says which tool owns it', /lap's job/.test(r.out));
}

/* 4. A MIXED QUEUE — the real shape after a lap: some green, most still gating.
 *    Exactly one merge, and it is the right one. */
{
  const r = run({ list: '1319\n1315\n1316\n1242\n',
                  states: { 1319: 'clean', 1315: 'blocked', 1316: 'blocked', 1242: 'dirty' } });
  const n = (r.merges.match(/\/merge/g) || []).length;
  check('one clean PR among four is merged, and only it', n === 1, `${n} merge call(s)`);
  check('…and it is 1319', /pulls\/1319\/merge/.test(r.merges));
  check('…and the summary counts the rest honestly',
        /merged=1 waiting-on-checks=2 needs-a-lap=1/.test(r.out),
        (r.out.match(/^merge-ready: .*$/m) || ['no summary line'])[0]);
}

/* 5. `unknown` IS RETRIED, NOT BELIEVED. GitHub computes mergeability lazily and
 *    answers `unknown` straight after a push — which is exactly when this runs.
 *    Believing the first answer would skip every PR the lap had just touched. */
{
  const r = run({ list: '1319\n', states: {} });   // always `unknown`
  check('a PR still computing is not merged', r.merges === '', r.merges.trim());
  check('…and it was asked more than once before giving up',
        /unknown/.test(r.out));
}

/* 6. A FAILED LIST FAILS THE RUN. `PRS=$(gh api …)` carries gh's status and this
 *    script has no `set -e`, so a failure leaves PRS empty and the loop runs
 *    zero times — printing character for character what a healthy empty queue
 *    prints. That is the shape that made the blind lap look green all morning
 *    (see test_pr_lap_list.mjs); it is not repeated here. */
{
  const r = run({ list: '', listExit: 1 });
  check('a failed PR-list call fails the run', r.code !== 0, `exit ${r.code}`);
  check('…and never reports an empty queue it never saw',
        !/merged=0 waiting-on-checks=0/.test(r.out));
}

/* 7. The honest empty queue still passes — the guard above must not cost that. */
{
  const r = run({ list: '', listExit: 0 });
  check('a genuinely empty queue is not an error', r.code === 0, `exit ${r.code}`);
  check('…and still prints the summary', /merged=0/.test(r.out));
}

/* 8. DRY RUN MERGES NOTHING. The flag exists so the first live run could be
 *    watched before it was trusted; a dry run that merged would be worse than
 *    no flag at all. */
{
  const r = run({ list: '1319\n', states: { 1319: 'clean' }, dry: '1' });
  const diagnostic = `exit ${r.code}; ${r.out.trim() || '(no output)'}`;
  check('a dry run exits cleanly', r.code === 0, diagnostic);
  check('a dry run merges nothing', r.merges === '', r.merges.trim());
  check('…and says what it would have done', /WOULD MERGE/.test(r.out), diagnostic);
}

/* 9. MERGE_ONLY THAT MATCHES NOTHING IS LOUD. Drafts and `hold` are filtered out
 *    of the list before this point, so a dispatch naming one gets no answer at
 *    all — and a silent no-op reads as "considered and declined". */
{
  const r = run({ list: '1315\n', states: { 1315: 'clean' }, only: '1210' });
  check('MERGE_ONLY that matches nothing fails the run', r.code !== 0, `exit ${r.code}`);
  check('…and names the number', /MERGE_ONLY=1210/.test(r.out));
  check('…and says `hold` is filtered before this point', /hold/.test(r.out));
  check('…and merged nothing while failing', r.merges === '', r.merges.trim());
}

/* 10. THE FILTER IS IN THE LIST QUERY, AND IT HAS TO STAY THERE. `hold` is the
 *     owner's park mechanism; a park a robot can overrule is not a park. This is
 *     a drift guard on the one line that enforces it. */
{
  const src = readFileSync(SH, 'utf8')
    .split('\n').filter((l) => !l.trim().startsWith('#')).join('\n');
  check('drafts are filtered out of the candidate list',
        /select\(\.draft==false\)/.test(src));
  check('`hold` is filtered out of the candidate list',
        /index\("hold"\) \| not/.test(src));
  check('no GraphQL-backed `gh pr|issue` verb is used — the budget that fails',
        /\bgh (pr|issue) (comment|create|merge|view|list|edit|close)\b/.exec(src) === null);
  check('the only state it merges on is `clean`',
        /^\s*clean\)/m.test(src) && !/blocked\|.*\)\s*$/m.test(src.replace(/blocked\|unstable\|has_hooks\)/, '')));
}

/* 11. THE WORKFLOW'S TRIGGER MUST BE ONE THAT FIRES FROM A NON-DEFAULT BRANCH.
 *
 * `schedule` and `workflow_run` fire ONLY from the repository's DEFAULT branch.
 * This repo's default is `main`; this workflow lives on `dev` and reaches `main`
 * only through promote-to-prod. A `schedule` written here would never fire once
 * — not late, not rarely: never — and the failure is SILENT, which is the whole
 * reason it is asserted rather than trusted to a comment.
 *
 * Checked 2026-09-14 rather than assumed: `main` carries 8 workflows and
 * chicago-4d-pr-lap.yml is not among them, yet the lap runs many times a day,
 * because `push:` triggers DO fire from the pushed branch's own copy; and every
 * scheduled run of chicago-4d-bake.yml reports `head_branch: main`.
 *
 * The first draft of this workflow had `schedule` and `workflow_run` and would
 * have merged nothing, ever, while looking entirely reasonable in review. */
{
  const wf = path.resolve(path.dirname(new URL(import.meta.url).pathname),
                          '..', '..', '..', '.github', 'workflows',
                          'chicago-4d-merge-ready.yml');
  const y = readFileSync(wf, 'utf8')
    .split('\n').filter((l) => !/^\s*#/.test(l)).join('\n');

  check('the workflow triggers on a push to dev — a trigger that fires from dev',
        /^on:[\s\S]*?^\s{2}push:\s*$[\s\S]*?branches:\s*\[\s*dev\s*\]/m.test(y));
  check('…and carries no `schedule`, which would never fire from a non-default branch',
        !/^\s{2}schedule:/m.test(y));
  check('…nor `workflow_run`, which has the same default-branch restriction',
        !/^\s{2}workflow_run:/m.test(y));
  check('…and still offers a manual dispatch', /^\s{2}workflow_dispatch:/m.test(y));
}

/* 12. THE WATCH LOOP MUST SURVIVE A SETTLED QUEUE, which is the success case.
 *
 * GitHub runs a `run:` block as `bash --noprofile --norc -eo pipefail {0}`, so
 * `-e` is on before the script's first line and a `set -uo pipefail` inside does
 * NOT turn it off. The loop counts how many pull requests are still `blocked`
 * with `grep -c`, and `grep -c` exits 1 when it counts nothing — so the step
 * died exactly when nothing was left waiting.
 *
 * Runs 2 and 3 on 2026-09-14 did their whole job, printed
 * `merged=0 waiting-on-checks=0 needs-a-lap=3`, and THEN exited 1. Run 1 passed
 * only because something was still gating. A failure that fires on success and
 * hides on failure is the worst shape available, so it is asserted here.
 *
 * Third time this GitHub default has bitten in one day: polecat-platform #165
 * aborted a janitor sweep on it, and pr-lap.sh's `PRS=$(...)` is its mirror. */
{
  const wf = path.resolve(path.dirname(new URL(import.meta.url).pathname),
                          '..', '..', '..', '.github', 'workflows',
                          'chicago-4d-merge-ready.yml');
  const y = readFileSync(wf, 'utf8');
  const body = y.split('\n').filter((l) => !/^\s*#/.test(l)).join('\n');
  check('the watch loop disarms the -e GitHub turns on for it',
        /^\s*set \+e\s*$/m.test(body));
  check('…and the blocked-count never fails the step when it counts nothing',
        /grep -c '\^blocked\$' \|\| true/.test(body));
}

/* 9. THE LABEL FILTER NAMES EXACTLY ONE LABEL, AND IT IS `hold` (T-1573).
 *
 * A SOURCE assertion rather than a behaviour run, and deliberately so: the filter
 * is a `--jq` expression evaluated inside the real `gh`, which the fakes above
 * stand in for — a behaviour case would be asserting about the fake's list, not
 * about the filter. What it pins is the one edit that would undo T-1573 while
 * looking like housekeeping.
 *
 * `resume` marks a run's OWN unfinished work: the branch carries it, the run ran
 * out of clock or budget or green, and merging it the moment GitHub calls it `clean` IS the resume,
 * done by machine for one REST call rather than by a whole run. It reads
 * exactly like a label belonging in this filter beside `hold`, and putting it
 * there would rebuild the fault T-1571 measured — three PRs on 2026-09-25 (#39,
 * #41, #42), none needing an owner's ruling, all three skipped by every pass
 * because the only label a run could apply was one every pass skips. `hold` is the
 * owner's park switch and stays the only exclusion.
 */
{
  const src = readFileSync(SH, 'utf8')
    .split('\n').filter((l) => !l.trim().startsWith('#')).join('\n');
  const filtered = [...src.matchAll(/index\("([^"]+)"\)\s*\|\s*not/g)].map((m) => m[1]);
  check('the label filter excludes `hold` and nothing else',
        filtered.length === 1 && filtered[0] === 'hold',
        filtered.length ? `filters ${filtered.join(', ')}` : 'no label filter found at all');
}

/* 13. WHICH REPOSITORY IT ACTS ON — NAMED, NEVER AMBIENT (T-1656).
 *
 * `merge-ready.sh` read its repository out of `$GITHUB_REPOSITORY` with a
 * `:-kevinrhaas/chicago` default, and that default reads as a safety net without
 * being one: in an Actions job the variable is always SET, so it never fires and the
 * value is whatever repository owns the JOB. `pr-rest.sh` carried the identical line
 * and was driven from the wrong side for real on 2026-09-27 (T-1652) — a steward run
 * works inside a chicago clone in a **polecat-platform** job, so its `resume`
 * commented a handoff reason on, and applied the label to, polecat-platform#104, an
 * unrelated pull request. Both repositories had a #104 open that day.
 *
 * So the REFUSAL is what needs proving, not the happy path above: run the script with
 * no `--repo`, from a checkout that cannot name itself, with the environment naming a
 * stranger as loudly as it can. It must refuse — and it must refuse BEFORE it reaches
 * `gh`, because the fault this closes is a call that LANDS somewhere else, not one
 * that fails.
 */
{
  const box = mkdtempSync(path.join(tmpdir(), 'repo-name-'));
  const bin = path.join(box, 'bin');
  mkdirSync(bin, { recursive: true });
  const log = path.join(box, 'gh.log');
  writeFileSync(log, '');
  // A checkout that is a git repository with NO origin: `--show-toplevel` answers and
  // `remote get-url origin` does not, so there is no name to default to — and still no
  // excuse to reach for the environment's.
  spawnSync('git', ['init', '--quiet', box]);
  const copy = path.join(box, 'merge-ready.sh');
  writeFileSync(copy, readFileSync(SH, 'utf8'));
  writeFileSync(path.join(bin, 'gh'),
                `#!/usr/bin/env bash\nprintf '%s\\n' "$*" >> ${log}\nexit 0\n`);
  chmodSync(path.join(bin, 'gh'), 0o755);
  const r = spawnSync('bash', [copy], {
    cwd: box,
    encoding: 'utf8',
    env: { ...process.env, PATH: `${bin}:${process.env.PATH}`, GH_TOKEN: 'fake',
           GITHUB_REPOSITORY: 'kevinrhaas/polecat-platform' },
  });
  const out = `${r.stdout || ''}${r.stderr || ''}`;
  const calls = readFileSync(log, 'utf8');
  rmSync(box, { recursive: true, force: true });
  check('a script that cannot name its repository refuses', r.status === 2, `exit ${r.status}`);
  check('…naming `--repo owner/name` as the way to say which',
        /--repo owner\/name/.test(out), out.trim().slice(0, 140) || 'said nothing');
  check('…and disowning $GITHUB_REPOSITORY by name, so the reason is readable',
        /GITHUB_REPOSITORY/.test(out));
  check('…and it never reached the repository the environment named',
        !/polecat-platform/.test(calls), calls.trim() || 'no gh call at all');
}

/* 14. …AND NO READ OF THE AMBIENT NAME SURVIVES IN THE SOURCE. tools/check_gh_rest.mjs
 * holds this line across all four steward scripts at once; this is the same line held
 * locally, beside the script's own tests, so a relapse fails here too. An escaped
 * `\$GITHUB_REPOSITORY` inside the refusal message is prose that disowns the
 * variable, not a read of it. */
{
  const src = readFileSync(SH, 'utf8')
    .split('\n').filter((l) => !l.trim().startsWith('#')).join('\n');
  check('nothing outside a comment reads $GITHUB_REPOSITORY',
        !/(^|[^\\])\$\{?GITHUB_REPOSITORY\b/.test(src),
        (src.match(/^.*GITHUB_REPOSITORY.*$/m) || [''])[0].trim());
  check('…and `--repo` is how a caller names it instead', /--repo/.test(src));
}

/* 15. …AND THE DEFAULT IS THE ORIGIN OF THE CHECKOUT THIS FILE IS IN, which is the
 * half the workflow leans on: ``.github/workflows/chicago-4d-merge-ready.yml`` passes no `--repo`, and its
 * actions/checkout sets the origin that answers for it. Proved in the shape the fault
 * was made in — the environment names polecat-platform as loudly as it can, the
 * checkout names chicago, and every REST path the script builds has to say chicago.
 */
{
  const box = mkdtempSync(path.join(tmpdir(), 'repo-default-'));
  const bin = path.join(box, 'bin');
  mkdirSync(bin, { recursive: true });
  const log = path.join(box, 'gh.log');
  writeFileSync(log, '');
  spawnSync('git', ['init', '--quiet', box]);
  // The remote is never contacted: `gh` below is a fake that lists no pull request, so
  // the script never reaches a `clean` PR and never reads a lap lock (T-2929) — the one
  // networked git it runs. Only the NAME is read.
  spawnSync('git', ['-C', box, 'remote', 'add', 'origin',
                    'https://github.com/kevinrhaas/chicago.git']);
  const copy = path.join(box, 'merge-ready.sh');
  writeFileSync(copy, readFileSync(SH, 'utf8'));
  writeFileSync(path.join(bin, 'gh'),
                `#!/usr/bin/env bash\nprintf '%s\\n' "$*" >> ${log}\nexit 0\n`);
  chmodSync(path.join(bin, 'gh'), 0o755);
  const r = spawnSync('bash', [copy], {
    cwd: box,
    encoding: 'utf8',
    env: { ...process.env, PATH: `${bin}:${process.env.PATH}`, GH_TOKEN: 'fake',
           GITHUB_REPOSITORY: 'kevinrhaas/polecat-platform' },
  });
  const calls = readFileSync(log, 'utf8');
  rmSync(box, { recursive: true, force: true });
  check('with no --repo, the repository is the checkout’s own origin remote',
        /repos\/kevinrhaas\/chicago\//.test(calls),
        calls.split('\n')[0] || 'no gh call at all');
  check('…and not one call names the repository the environment named',
        !/polecat-platform/.test(calls), (calls.match(/^.*polecat-platform.*$/m) || [''])[0]);
  check('…and the script runs on to its own summary', r.status === 0, `exit ${r.status}`);
}

console.log(failures ? `\n${failures} FAILED` : '\nall passed');
process.exit(failures ? 1 : 0);
