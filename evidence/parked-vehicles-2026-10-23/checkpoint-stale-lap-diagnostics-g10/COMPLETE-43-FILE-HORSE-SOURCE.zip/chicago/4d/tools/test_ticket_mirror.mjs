#!/usr/bin/env node
/**
 * test_ticket_mirror.mjs — closing a ticket does not leave the published mirror
 * stale, AND the gate that catches a genuinely stale mirror still catches one.
 *
 * WHY THIS EXISTS (T-0154). `site/4d/tickets.json` is a verbatim copy of
 * `tickets/tickets.json`, and `tools/check_published.mjs` compares the two byte
 * for byte. `ticket.mjs done` rewrites the source. So the order AGENTS.md states
 * — publish in the same commit, then push, then close the ticket in the merging
 * PR with the number that push just produced — ended red every single time, and
 * what actually held it together was a REMEMBERED extra `publish.sh` after the
 * close. That is the kind of unwritten step that goes wrong at 3am, and it did:
 * T-0153/PR #318, gate red at 05:11Z on exactly this.
 *
 * The fix is that the writer of the file maintains its mirror. The DANGER in that
 * fix is obvious and the ticket's acceptance names it: a tool that refreshes the
 * mirror whenever it runs would launder a genuinely stale mirror, and the fault
 * class this gate exists for (#145, three parcels) would be invisible again. So
 * this file asserts BOTH halves, and the second one is the important one.
 *
 * EVERYTHING RUNS IN A SANDBOX. The tools resolve their paths from their own
 * location, so a temporary tree of the shape they expect — `<tmp>/chicago/4d/…`
 * beside `<tmp>/site/4d/` — gives them a whole world to be wrong in
 * without touching the repository. An earlier draft of this test mutated the real
 * tickets.json and restored it afterwards; a crash in the middle of that leaves a
 * working tree nobody can explain, which is not a thing to build a gate on.
 */
import { mkdtempSync, mkdirSync, cpSync, rmSync, readFileSync, writeFileSync,
  existsSync, lstatSync, realpathSync, readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import path from 'node:path';

const HERE = path.dirname(new URL(import.meta.url).pathname);
const REPO = path.resolve(HERE, '..');

let failures = 0;
const check = (what, ok, detail) => {
  console.log(`  ${ok ? 'ok  ' : 'FAIL'}  ${what}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failures += 1;
};

/* ------------------------------------------------------------------ sandbox */

const tmp = mkdtempSync(path.join(tmpdir(), 'c4d-ticket-mirror-'));
const APP = path.join(tmp, 'chicago', '4d');
const SITE = path.join(tmp, 'site', '4d');
mkdirSync(path.join(APP, 'tools'), { recursive: true });
mkdirSync(SITE, { recursive: true });
// The three tools under test, and the ticket files they read. Nothing else: the
// sandbox site holds one file, so check_published has exactly one thing to say.
for (const f of ['ticket.mjs', 'check_published.mjs', 'publish.sh']) {
  cpSync(path.join(REPO, 'tools', f), path.join(APP, 'tools', f));
}
// The ticket FILES, never a clone's .git: since 2026-09-23 tickets/ is a clone of
// kevinrhaas/chicago-tickets, and a sandbox carrying its .git would be a tickets repo
// of its own (REPO MODE) — this test is about the embedded mode's mirror contract.
//
// DEREFERENCED, and then PROVED to be the sandbox's own files. A worktree may carry
// tickets/ as a SYMLINK to the real clone, and cpSync copies a symlink as a symlink
// unless told otherwise — the filter above never runs inside it. On 2026-09-24 that is
// exactly what happened: the sandbox's `ticket.mjs done … --pr 9999` wrote through the
// link into the real clone and PUSHED to kevinrhaas/chicago-tickets main (T-1502's pr
// became 9999). So the copy dereferences, and the test refuses to go on unless the
// sandbox's tickets/ is a real directory inside the sandbox with no .git anywhere in it.
// Recovery evidence is not a ticket input. Copying its archived models made the
// standing-horse preflight exhaust /tmp before the mirror assertions could run.
// Keep every ticket and metadata file; leave only evidence and Git internals out.
const ticketsRoot = path.join(REPO, 'tickets');
try {
  cpSync(ticketsRoot, path.join(APP, 'tickets'), {
    recursive: true, dereference: true,
    filter: (src) => path.basename(src) !== '.git'
      && path.relative(ticketsRoot, src).split(path.sep)[0] !== 'evidence',
  });
} catch (error) {
  rmSync(tmp, { recursive: true, force: true });
  throw error;
}
{
  const own = path.join(APP, 'tickets');
  const real = realpathSync(own);
  const inside = real === own || real.startsWith(realpathSync(tmp) + path.sep);
  if (lstatSync(own).isSymbolicLink() || !inside || existsSync(path.join(own, '.git'))
      || existsSync(path.join(own, 'evidence'))) {
    console.error(`ticket mirror — REFUSED: the sandbox's tickets/ resolves to ${real}, ` +
      'not to a plain copy inside the sandbox; running on would write to the real tickets repo');
    rmSync(tmp, { recursive: true, force: true });
    process.exit(1);
  }
}

const SRC = path.join(APP, 'tickets', 'tickets.json');
const MIRROR = path.join(SITE, 'tickets.json');
const BOARD = path.join(APP, 'tickets', 'BOARD.md');

// stderr is CAPTURED, not inherited: half of what runs below is expected to fail,
// and a gate whose green log is full of other tools' FAILED banners teaches whoever
// reads it to ignore banners.
const RUN = { cwd: APP, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] };
const said = (e) => `${e.stdout ?? ''}${e.stderr ?? ''}`;
const ticket = (...args) => execFileSync('node', [path.join(APP, 'tools', 'ticket.mjs'), ...args], RUN);
/** The gate, as a boolean plus what it said. */
const published = () => {
  try {
    return { ok: true, out: execFileSync('node',
      [path.join(APP, 'tools', 'check_published.mjs')], RUN) };
  } catch (e) {
    return { ok: false, out: said(e) };
  }
};

try {
  console.log(`ticket mirror — sandbox at ${tmp}`);

  /* --- half zero: an UNBUILT tree builds itself (T-0937) ----------------- */
  //
  // BOARD.md, tickets.json and the mirror are untracked as of T-0937 — they were
  // the most-conflicting files in the repository, because a run's first act is
  // `ticket.mjs claim` and that rewrites all three before any work is done. So a
  // fresh clone and every CI checkout now start with NONE of them, and each reader
  // has to be able to make its own.
  //
  // This half exists because the regression is silent in the worst possible way:
  // on a developer's machine the three files survive from the last run, so the gate
  // stays green while a CI checkout publishes no /4d/tickets.json at all —
  // and that URL is Manager's queue card (T-0030). Nobody would see a red.
  //
  // The mirror assertion is the sharp one. `mirrorTickets` deliberately copies only
  // when the source was actually rewritten, so that a mirror somebody else made
  // stale is never laundered (half two below). An absent mirror is not a stale one,
  // and it must be filled anyway — that is the case this line pins.
  for (const f of [SRC, BOARD, MIRROR]) if (existsSync(f)) rmSync(f);
  ticket('board');
  check('an unbuilt tree generates tickets.json', existsSync(SRC));
  check('…and BOARD.md', existsSync(BOARD));
  check('…and the published mirror, though nothing rewrote the source before it',
    existsSync(MIRROR) && readFileSync(MIRROR, 'utf8') === readFileSync(SRC, 'utf8'),
    existsSync(MIRROR) ? 'mirror matches source' : 'mirror absent');

  // A published tree: the board regenerated, then copied the way publish.sh
  // copies it. This is the state every run is in when it reaches step 2.
  ticket('board');
  writeFileSync(MIRROR, readFileSync(SRC));
  check('a freshly published sandbox passes the mirror gate', published().ok);

  // The ticket to close. Any workable one; the queue's own order picks it, so
  // this test does not care which tickets exist — EXCEPT that it skips one carrying
  // an `## Image gate` (T-2402). `done` refuses such a ticket until its building
  // matches its pictures (T-2368), and this sandbox holds no image_gate.mjs and no
  // reference views, so with an image-gated ticket at the top of the live queue
  // (the owner put T-2369 there on 2026-10-12) this step went red on every PR for
  // a refusal it does not measure. If every workable ticket is image-gated, the
  // close passes the gate with --anyway, which is that refusal's own way past.
  const workable = ticket('list', '--workable').trim().split('\n').filter(Boolean)
    .map((line) => line.split(/\s+/)[0]);
  const ticketFiles = new Map();
  const walk = (dir) => {
    for (const e of readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory()) walk(path.join(dir, e.name));
      else if (/^T-\d{4}-.*\.md$/.test(e.name)) ticketFiles.set(e.name.slice(0, 6), path.join(dir, e.name));
    }
  };
  walk(path.join(APP, 'tickets'));
  const imageGated = (id) => ticketFiles.has(id)
    && /^## Image gate/m.test(readFileSync(ticketFiles.get(id), 'utf8'));
  const victim = workable.find((id) => !imageGated(id)) ?? workable[0];
  check('the sandbox queue offers a ticket to close', /^T-\d{4}$/.test(victim ?? ''), victim);

  /* --- half one: the documented order ends green ------------------------- */
  //
  // Exactly the sequence in AGENTS.md, from the point publish.sh has run: push,
  // open the PR, close the ticket with the number the PR just got. No second
  // publish, because a run following the documented steps does not do one.
  ticket('done', victim, '--pr', '9999', ...(imageGated(victim)
    ? ['--anyway', '--why', 'sandbox: the image gate is not what this test measures'] : []));
  const afterClose = published();
  check('closing a ticket leaves the published mirror fresh', afterClose.ok,
    afterClose.ok ? 'no remembered publish.sh needed' : afterClose.out.trim().split('\n').pop());
  check('…and the mirror really is the closed board, not the old one',
    readFileSync(MIRROR, 'utf8') === readFileSync(SRC, 'utf8')
      && readFileSync(MIRROR, 'utf8').includes('"pr": "9999"'),
    `${readFileSync(MIRROR, 'utf8').length} bytes`);

  // THE FINISH ORDER IS A FACT THE MIRROR CARRIES. `closed` is a day, so two
  // tickets finished on the same day used to sort by ticket id — the board read
  // as if the work had been done alphabetically. `done` now stamps the instant,
  // and the board's finished section leads with the ticket that just closed.
  const mirror = JSON.parse(readFileSync(MIRROR, 'utf8'));
  const closedTicket = mirror.tickets.find((t) => t.id === victim);
  check('the closed ticket carries the instant it finished, not only the day',
    !!closedTicket?.closed_at && !Number.isNaN(Date.parse(closedTicket.closed_at)),
    closedTicket?.closed_at ?? 'closed_at absent');
  const finishedHead = /## Finished, newest first[^\n]*\n\n- \*\*(T-\d{4})\*\*/
    .exec(readFileSync(BOARD, 'utf8'));
  check('and the board lists it first under Finished, newest first',
    finishedHead?.[1] === victim, finishedHead ? `leads with ${finishedHead[1]}` : 'no such section');

  /* --- half two: the gate is not weaker ---------------------------------- */
  //
  // This is the half the acceptance clause insists on. A mirror somebody else
  // made stale — a hand edit, a bad merge, a publish that half-ran — must still
  // fail, and running the ticket tool over it must NOT quietly repair it. If a
  // no-op regeneration laundered the mirror, the gate would be reporting on the
  // tool's own last act rather than on what the site ships.
  writeFileSync(MIRROR, `${readFileSync(MIRROR, 'utf8')}\n// hand-edited\n`);
  const dirtied = published();
  check('a hand-staled mirror still fails the gate', !dirtied.ok,
    dirtied.out.includes('tickets.json DIFFERS') ? 'and it names tickets.json' : 'WITHOUT naming it');

  ticket('board');   // a regeneration that changes nothing in the source
  const afterNoop = published();
  check('a no-op regeneration does NOT launder that stale mirror', !afterNoop.ok,
    afterNoop.ok ? 'the mirror was silently repaired — the gate has been weakened' : 'still red');

  writeFileSync(MIRROR, readFileSync(SRC));
  check('and republishing clears it again', published().ok);

  /* --- half three: `check` reports a stale board, and never repairs it ---- */
  //
  // T-1341. `check` used to regenerate the pair on its way past, so on a stale tree
  // it rewrote tickets.json and the mirror and the drift was gone before anyone saw
  // it — the T-0856 check-that-repairs fault. It now compares. The sandbox queue may
  // carry faults of its own (embedded mode charges them all), so the exit status is
  // not the assertion: what it SAYS about the board, and the bytes, are.
  const bytes = () => [SRC, BOARD, MIRROR].map((f) => (existsSync(f) ? readFileSync(f, 'utf8') : null));
  const checkSays = () => { try { return { code: 0, out: ticket('check') }; } catch (e) { return { code: e.status, out: said(e) }; } };
  ticket('board');
  writeFileSync(MIRROR, readFileSync(SRC));
  const before = bytes();
  const clean = checkSays();
  check('`check` on a current board does not call it stale', !clean.out.includes('is STALE'));
  check('…and writes nothing', bytes().every((b, i) => b === before[i]));

  writeFileSync(SRC, readFileSync(SRC, 'utf8').replace('"tickets": [', '"tickets": [ ').replace(/"title": "/, '"title": "STALE '));
  const staled = bytes();
  const stale = checkSays();
  check('`check` on a stale tickets.json fails and names it', stale.code !== 0
    && stale.out.includes('tickets/tickets.json is STALE'), stale.out.includes('is STALE') ? 'named' : 'silent');
  check('…and writes NOTHING — not the source, not the board, not the mirror',
    bytes().every((b, i) => b === staled[i]), 'repairing is `board`\'s job, not the gate\'s');
  ticket('board');
  writeFileSync(MIRROR, readFileSync(SRC));
  check('and `board` is what clears it', !checkSays().out.includes('is STALE'));

  /* --- the pin: two copies of one fact cannot drift ---------------------- */
  //
  // ticket.mjs hard-codes where publish.sh puts this file. `check` pins the copy
  // line so the pair cannot drift into mirroring different paths in silence.
  const pubSh = path.join(APP, 'tools', 'publish.sh');
  const kept = readFileSync(pubSh, 'utf8');
  writeFileSync(pubSh, kept.replace('cp -f tickets/tickets.json "$SITE/tickets.json"',
    'cp -f tickets/tickets.json "$SITE/board/tickets.json"'));
  let pinned = '';
  try { ticket('check'); } catch (e) { pinned = said(e); }
  check('moving publish.sh\'s copy is refused by `ticket.mjs check`',
    pinned.includes('no longer contains'),
    pinned ? 'and it names the reconciliation' : 'check stayed green');
  writeFileSync(pubSh, kept);
} finally {
  if (existsSync(tmp)) rmSync(tmp, { recursive: true, force: true });
}

console.log(failures ? `ticket mirror FAILED — ${failures} assertion(s)` : 'ticket mirror OK');
process.exit(failures ? 1 : 0);
