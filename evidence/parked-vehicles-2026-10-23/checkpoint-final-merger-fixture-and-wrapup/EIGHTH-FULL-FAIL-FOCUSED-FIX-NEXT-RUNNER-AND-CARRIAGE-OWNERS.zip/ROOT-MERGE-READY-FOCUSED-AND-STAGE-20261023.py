from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime
sys.path.insert(0,'/workspace/shared');import owned_child_reaper_20261023 as owned
owned.enable();R=Path('/workspace/chicago-waistcoat');A=R/'chicago/4d';S=Path('/workspace/shared');P=S/'T2800-MERGE-READY-FIXTURE-SHELL-STATE-SOURCE-PROPOSAL-20261023';D=S/'T2800-MERGE-READY-SHELL-STATE-FOCUSED-V2-ACTUAL-20261023';D.mkdir();E=os.environ.copy();E['PATH']='/workspace/shared/w01-python-sum-recovery-20261022/venv311/bin:/workspace/shared/chicago-tools/usr/bin:'+E['PATH'];E.update(CHECK_JOBS='1',NODE_OPTIONS='--v8-pool-size=1 --disable-sigusr1',UV_THREADPOOL_SIZE='1',GOMAXPROCS='1',GIT_CONFIG_COUNT='3',GIT_CONFIG_KEY_0='index.threads',GIT_CONFIG_VALUE_0='1',GIT_CONFIG_KEY_1='pack.threads',GIT_CONFIG_VALUE_1='1',GIT_CONFIG_KEY_2='core.preloadIndex',GIT_CONFIG_VALUE_2='false')
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:E[k]='1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):
 v=subprocess.check_output(['git','-C',str(R),*a],env=E,text=True).strip();owned.reap_orphans();return v
try:
 assert git('write-tree')=='d089109a601adcccf57a09210af8914349fbed63';assert not git('diff','--name-only')
 target=A/'tools/test_merge_ready.mjs';assert sha(target)=='fa2a10bc242d9b413800312e9f1587514bc0cfeb18820a5f06758aa19f028ee2';proposed=(P/'test_merge_ready.mjs.PROPOSED').read_text();assert hashlib.sha256(proposed.encode()).hexdigest()=='1fac71965817b379128516f9fc75cb1f75641d9d1b2afa9dfc548d6e697aa901'
 needle='path.dirname(new URL(import.meta.url).pathname)';assert needle in proposed;anchored=proposed.replace(needle,json.dumps(str(A/'tools')));positive=D/'positive-real-merger.mjs';positive.write_text(anchored)
 needle="states: { 1319: 'clean' }, dry: '1'";assert anchored.count(needle)==1;negative=D/'blocked-dryrun-negative.mjs';negative.write_text(anchored.replace(needle,"states: { 1319: 'blocked' }, dry: '1'"))
 wrapper=S/'T2800-LAP-LOCK-SERIAL-DEPTH-FOCUSED-ACTUAL-20261023/same-two-shell-depth.sh';production=R/'.github/steward/merge-ready.sh';pin=sha(production);rows=[]
 for name,p,expected in [('positive',positive,0),('blocked-dryrun-negative',negative,1)]:
  r=owned.run(['bash',str(wrapper),str(p)],A,E,D/(name+'.log'),90);r['new_owned_orphans_reaped_count']=len(r.pop('new_owned_orphans_reaped',[]));rows.append({'name':name,'expected_returncode':expected,**r});print(name,json.dumps(r),flush=True);print((D/(name+'.log')).read_text()[-3500:],flush=True)
  (D/'RUNS.json').write_text(json.dumps(rows,indent=2)+'\n');assert r['returncode']==expected
 assert sha(production)==pin;target.write_text(proposed)
 status=A/'docs/STATUS.md';status.write_text(status.read_text()+"\nThe final merge-ready dry-run fixture emits its fixed GitHub states as shell-quoted Bash cases rather than starting an unnecessary nested Node interpreter. Every original merger assertion remains; dry-run exit status and output are recorded. Production merge/lock/workflow code is unchanged. A complete1054-step attempt finished with one dry-run fixture failure; the old assertion did not record output, so the exact transient cause is not established. Focused real-merger and deliberately blocked dry-run negative controls are recorded externally; a fresh complete gate is required before commit.\n")
 git('add','chicago/4d/tools/test_merge_ready.mjs','chicago/4d/docs/STATUS.md');tree=git('write-tree');paths=git('diff','--cached','--name-only','HEAD').splitlines();assert len(paths)==43 and not git('diff','--name-only');assert sha(production)==pin
 result={'status':'FOCUSED_PASS_AND_NEGATIVE_CONTROL_PRESERVED_NOT_WHOLE_PASS','runs':rows,'production_merger_unchanged_sha256':pin,'fixture_sha256':sha(target),'app_base':git('rev-parse','HEAD'),'staged_tree':tree,'paths':paths,'path_count':43,'app_commit':None,'fresh_full_gate_required':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(D/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print('STAGED',json.dumps(result),flush=True)
finally:
 c=owned.finish();(D/'CLEANUP.json').write_text(json.dumps(c,indent=2)+'\n');print('CLEANUP',json.dumps(c),flush=True)
