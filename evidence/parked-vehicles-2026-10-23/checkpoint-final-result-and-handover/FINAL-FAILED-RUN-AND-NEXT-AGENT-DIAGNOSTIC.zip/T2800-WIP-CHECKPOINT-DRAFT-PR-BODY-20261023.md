Adds one selectable reconstructed horse to the 1835 Western Hotel wagon yard, with a 12-second planted weight shift, owned material/mixer lifetime and bounded actual drawn-yard support. Existing people, carriages and wagons are retained. The licensed modern model and reconstruction are credited separately.

WIP checkpoint: the latest complete local check ran all 1,054 steps and reported one failure in the live-lap-lock test (stale-lock lap/push case). The preceding merger dry-run failure is fixed; its real-merger focused test passed and deliberately blocked negative control remained red. Production merge scripts, locks and workflows are unchanged. The execution connection subsequently disappeared; the recovered raw check/preflight logs retain the actual failure. This is not a local whole-suite PASS.

The horse's standard-loader/Mixer check passed 65 keys and 64 midpoints. Actual committed-head publication and fresh CI results must be recorded separately. Published desktop/mobile yard checks, photographic anatomy/coat/hair/eyes, head/tail composition, walking, tack, teams, drivers and riding remain unfinished under T-2800/T-2803.

Keep this PR draft until fresh normal CI for the actual source/current test-merge is green and the current DEV delta is reviewed. No admin or check bypass; broad tickets remain open.
