"""Focused checks of copied proposed modules; no Blender or repository writes."""
import collections, dataclasses, importlib.util, json, math, pathlib, sys, types
ROOT=pathlib.Path('/workspace/chicago/chicago/4d')
OUT=pathlib.Path(__file__).parent; PROPOSED=OUT/'proposed'
sys.path[:0]=[str(PROPOSED/'generators'),str(ROOT/'generators')]
sys.modules.setdefault('bpy',types.ModuleType('bpy'))
from archetypes import frame_tavern as proposed
from archetypes import frame_tavern_params as params
from common.mesh import MeshBuilder

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
old=load('original_tremont_archetype', ROOT/'generators/archetypes/frame_tavern.py')
oldparams=load('original_tremont_parameters', ROOT/'generators/archetypes/frame_tavern_params.py')

def emit(self,mats=None): return self,list(mats or [])
MeshBuilder.to_object=emit
for mod in (old,proposed): mod.simple_material=lambda name,*args,**kw:(name,args,kw)
def signature(result):
    b,mats=result
    return b.verts,b.faces,b.conf,b.mat_index,b.named,mats

legacy=0
for p in sorted((ROOT/'data/structures').glob('*.json')):
    rec=json.loads(p.read_text())
    if rec.get('archetype')!='frame_tavern':continue
    for ph in rec['phases']:
        before=oldparams.from_phase(ph,rec); after=params.from_phase(ph,rec)
        assert dataclasses.asdict(before)==dataclasses.asdict(after), (rec['id'],ph['id'],'params changed')
        assert signature(old.build(before,rec['id']))==signature(proposed.build(after,rec['id'])), (rec['id'],ph['id'],'geometry changed')
        legacy+=1
assert legacy>0
print(f'PASS legacy resolved params + accumulated geometry/materials unchanged: {legacy} phases')

rec=json.loads((PROPOSED/'data/structures/tremont_house_1.json').read_text()); ph=rec['phases'][0]
p=params.from_phase(ph,rec)
assert p.stories==3 and p.elevation_scheme=='corner_gable' and p.shutters=='green'
assert p.width_m==15.24 and p.depth_m==9.14 and p.wall_height_m==7.8
assert 'elevation_scheme' in params.CONSUMED
original_rec=json.loads((ROOT/'data/structures/tremont_house_1.json').read_text())
for key in ('position','footprint','documented_range'):
    assert ph[key]==original_rec['phases'][0][key],key
print('PASS actual proposed phase resolves; placement/footprint/date untouched')

windows=[];doors=[]
win_original,door_original=proposed._win,proposed._door
def win(*args,**kwargs):
    windows.append(args[2:]); return win_original(*args,**kwargs)
def door(*args,**kwargs):
    doors.append(args[2:]); return door_original(*args,**kwargs)
proposed._win,proposed._door=win,door
b,mats=proposed.build(p,rec['id']);proposed._win,proposed._door=win_original,door_original
assert len(windows)==44,len(windows)
assert len(doors)==4,len(doors)
counts=collections.Counter((a,plane) for a,plane,*rest in windows)
assert counts=={('x',0.0):8,('x',15.24):8,('y',0.0):14,('y',9.14):14},counts
assert sum(m==proposed.M_SHUTTER for m in b.mat_index)==44*2*6
assert all(math.isfinite(c) for v in b.verts for c in v)
assert all(0<=c<=1 for c in b.conf)
assert all(abs(c-1.0)<1e-8 for fi,m in enumerate(b.mat_index) if m==proposed.M_SHUTTER for c in [b.conf[b.faces[fi][0]]])
# Centres stay off corners and every opening lies within the storey envelope.
for axis,plane,outward,u0,u1,z0,z1,conf in windows:
    span=p.depth_m if axis=='x' else p.width_m
    assert 0<u0<u1<span
    assert 0<z0<z1<p.wall_height_m
print('PASS geometry: 3-bay short gables, 5-bay long walls, 3 floors, 44 windows, 4 doors, 88 closed shutter leaves')

# All six shutter faces must have nonzero area (including their thickness faces).
for face,mat in zip(b.faces,b.mat_index):
    if mat!=proposed.M_SHUTTER:continue
    a,c,d=[b.verts[i] for i in face[:3]]
    ab=[c[i]-a[i] for i in range(3)]; ac=[d[i]-a[i] for i in range(3)]
    cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
    assert sum(x*x for x in cross)>1e-10
print('PASS shutter leaves have finite, nondegenerate outward and thickness faces on both wall axes')

invalid=[{'elevation_scheme':'unknown'},{'width_m':8.0},{'depth_m':16.0}, {'roof_type':'hip'}, {'shutter_type':'louvred'}, {'upper_windows':7}, {'wall_height_m':5.0}, {'rear_ell':True}, {'log_wing':True}, {'gallery':True}, {'entrance_frontispiece':True}]
for change in invalid:
    try:dataclasses.replace(p,**change).validate()
    except params.ParamError:pass
    else:raise AssertionError(('accepted incompatible corner scheme',change))
print(f'PASS rejects incompatible/narrow/too-low configurations: {len(invalid)} cases')

# Off means no shutter material faces, not hidden branches contributing vertices.
p2=dataclasses.replace(p,shutters=None);b2,_=proposed.build(p2,rec['id'])
assert not any(m==proposed.M_SHUTTER for m in b2.mat_index)
print('PASS shutter option off emits no shutter faces')
try:
    import jsonschema
    jsonschema.Draft202012Validator(json.loads((ROOT/'data/structures.schema.json').read_text()),format_checker=jsonschema.FormatChecker()).validate(rec)
    print('PASS proposed structure JSON schema')
except ImportError: print('SKIP schema: jsonschema unavailable')
print('ALL FOCUSED CHECKS PASSED; accumulated geometry only, no Blender GLB/bake/render validation')
