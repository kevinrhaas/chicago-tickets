// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const source=await readFile(new URL('./tools/human_frame_compare.js',import.meta.url),'utf8');
const isolated=source.slice(source.indexOf('export function maximumPointDisplacement'),source.indexOf('\nfunction release')).replace('export ','');
const context=vm.createContext({});vm.runInContext(isolated,context);const f=context.maximumPointDisplacement;
assert.equal(f([0,0,0,1,1,1],[0,0,0,1,1,1]),0);
assert.ok(Math.abs(f([0,0,0],[.00003,.00004,0])-.00005)<1e-14);
assert.throws(()=>f([0,0,0],[0,0]));assert.throws(()=>f([0,0],[0,0]));assert.throws(()=>f([0,0,0],[NaN,0,0]));
console.log('PASS: 5 pure displacement arithmetic/refusal assertions; no browser/actual-asset proof');
