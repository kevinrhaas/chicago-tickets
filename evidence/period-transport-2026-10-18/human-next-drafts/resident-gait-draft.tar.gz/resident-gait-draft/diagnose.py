#!/usr/bin/env python3
"""Source-math diagnostic only; no bpy import, export, browser, or application writes."""
import json,math,pathlib,hashlib
R=pathlib.Path('/workspace/chicago/chicago/4d');P=pathlib.Path(__file__).parent
builder=(R/'tools/human_teamster_blend.py').read_text();recipe=json.loads((R/'data/humans/recipes/worker_1835.json').read_text());scale=float(recipe.get('height_scale',1))
# Refuse stale diagnostic if the source motion recipe changes; values below are exact source rules.
for line in ["math.radians(18)*math.sin(phase+(0 if name.endswith('_l') else math.pi))","-math.radians(25)*max(0,math.sin(phase+(0 if name.endswith('_l') else math.pi)))","act['speed_m_s']=1.0","for frame in range(1,length+2,5)"]:
 if line not in builder:raise ValueError('source motion changed; re-review diagnostic')
def ident():return [[float(i==j)for j in range(4)]for i in range(4)]
def mm(a,b):return [[sum(a[i][k]*b[k][j]for k in range(4))for j in range(4)]for i in range(4)]
def pivot_x(h,a):
 c=math.cos(a);s=math.sin(a);r=ident();r[1][1]=r[2][2]=c;r[1][2]=-s;r[2][1]=s
 for i in range(3):r[i][3]=h[i]-sum(r[i][j]*h[j]for j in range(3))
 return r
def transform(m,p):return [sum(m[i][j]*p[j]for j in range(3))+m[i][3]for i in range(3)]
def skin(p,w,deform):return [sum(weight*transform(deform[bone],p)[i]for bone,weight in w.items())for i in range(3)]
def deformations(bones,phase,walk=True):
 out={}
 def visit(n):
  if n in out:return out[n]
  b=bones[n];parent=b['parent'];prior=visit(parent)if parent else ident();angle=0
  if walk and n.startswith('thigh'):angle=math.radians(18)*math.sin(phase+(0 if n.endswith('_l')else math.pi))
  if walk and n.startswith('calf'):angle=-math.radians(25)*max(0,math.sin(phase+(0 if n.endswith('_l')else math.pi)))
  if n=='spine_02':angle=math.radians(.6)*math.sin(phase)
  # For lower limbs, rest-basis conjugation cancels exactly in D=Gpose*inverse(Grest).
  out[n]=mm(prior,pivot_x([v*scale for v in b['head_m']],angle));return out[n]
 for n in bones:visit(n)
 return out
report={'builder_sha256':hashlib.sha256(builder.encode()).hexdigest(),'diagnostic_basis':'Source keyed poses only: world-X thigh/calf rotations conjugated into each rest-bone basis, rest-global pivot transforms and prepared LBS weights. Not actual exported GLB skin.','assumptions':['Blender linear blend skinning, no preserve-volume modifier; no shape keys active','Original authored rest pose and prepared semantic weights; no inferred bone locations','Keys only; Blender default quaternion component BEZIER evaluation/export sampling not replicated','No ground/root compensation exists in current walk source'],'variants':{}}
for variant in recipe['proof_variants'][:2]:
 path=R/variant['body_input'];body=json.loads(path.read_text());bones={b['name']:b for b in body['skeleton']};entry={'person_id':variant['person_reference_id'],'body_input':variant['body_input'],'body_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'age_parameter':variant['body_parameters']['engineering_age_years'],'age_is':'reconstructed authoring parameter, not exact resident age','legs':{}}
 for side in ['l','r']:
  # Exact source candidate predicate/ring dimensions. Ground ring plus duplicate sole rim,
  # and central triangulation vertex carry source-authored foot/ball blend weights.
  candidates=[p for m in body['meshes']for p,w in zip(m['positions_m'],m['weights'])if sum(v for b,v in w.items()if b in('foot_'+side,'ball_'+side))>.35 and p[1]<.16]
  xmin,xmax=min(p[0]for p in candidates),max(p[0]for p in candidates);zmin,zmax=min(p[2]for p in candidates),max(p[2]for p in candidates);cx=(xmin+xmax)/2;cz=(zmin+zmax)/2;rx=(xmax-xmin)/2+recipe['shoe_offset_m']/scale;rz=(zmax-zmin)/2+recipe['shoe_offset_m']/scale
  sole=[]
  for k in range(20):
   t=2*math.pi*k/20;z=cz+rz*math.sin(t);blend=max(0,min(1,(z-bones['ball_'+side]['head_m'][2]+.04)/.08));sole.append(([v*scale for v in [cx+rx*math.cos(t),0,z]],{'foot_'+side:1-blend,'ball_'+side:blend}))
  sole.append(([cx*scale,0,cz*scale],{'foot_'+side:1}))
  footbody=[([v*scale for v in p],w)for m in body['meshes']for p,w in zip(m['positions_m'],m['weights'])if sum(v for b,v in w.items()if b in('foot_'+side,'ball_'+side))>.35 and p[1]<.17]
  samples=[]
  for frame in range(1,32,5):
   t=(frame-1)/30;d=deformations(bones,2*math.pi*t);s=[skin(p,w,d)for p,w in sole];bp=[skin(p,w,d)for p,w in footbody];center=s[-1];samples.append({'frame':frame,'time_s':t,'sole_min_y_m':min(p[1]for p in s),'sole_max_y_m':max(p[1]for p in s),'sole_center_xyz_m':center,'sole_center_compensated_z_m':center[2]+t,'footbody_min_y_m':min(p[1]for p in bp),'footbody_max_y_m':max(p[1]for p in bp)})
  centerzs=[s['sole_center_compensated_z_m']for s in samples];origin=[s['sole_center_xyz_m']for s in samples];hip=bones['thigh_'+side]['head_m'];knee=bones['calf_'+side]['head_m'];ankle=bones['foot_'+side]['head_m'];length=lambda a,b:math.dist(a,b)*scale
  L=length(hip,knee)+length(knee,ankle);dx=(ankle[0]-hip[0])*scale;dy=(hip[1]-ankle[1])*scale;dz=(ankle[2]-hip[2])*scale
  half_stance=.5*1.0*1.0*.62
  reach=max(math.sqrt(dx*dx+dy*dy+(dz+sign*half_stance)**2)for sign in [-1,1])
  vertical_allowed=math.sqrt(max(0,(.995*L)**2-dx*dx-(abs(dz)+half_stance)**2))
  entry['legs'][side]={'hypothetical_contact_solver_reach':{'assumed_speed_m_s':1.0,'assumed_cycle_duration_s':1.0,'proposed_stance_fraction':.62,'target_half_stance_travel_m':half_stance,'fixed_hip_target_overreach_m':max(0,reach-L),'minimum_pelvis_lowering_for_99_5_percent_reach_m':max(0,dy-vertical_allowed),'status':'engineering feasibility proposal, not authored motion or biological measurement'},'prepared_candidate_vertices':len(candidates),'prepared_footbody_sample_vertices':len(footbody),'unique_authored_sole_points':len(sole),'prepared_joints_m':{'hip':hip,'knee':knee,'ankle':ankle,'ball':bones['ball_'+side]['head_m']},'segment_lengths_m':{'hip_knee':length(hip,knee),'knee_ankle':length(knee,ankle)},'samples':samples,'keyed_sole_min_y_m':min(s['sole_min_y_m']for s in samples),'keyed_sole_max_y_m':max(s['sole_max_y_m']for s in samples),'full_cycle_compensated_center_z_range_m':max(centerzs)-min(centerzs),'full_cycle_is_not_stance_drift':True,'center_airborne_key_count_over_10mm':sum(p[1]>.01 for p in origin),'sole_penetrating_key_count_below_minus_5mm':sum(s['sole_min_y_m']<-.005 for s in samples),'idle_sole_y_m':0.0}
 report['variants'][variant['id']]=entry
(P/'source-keyed-contact-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:{side:{key:val for key,val in leg.items()if key in ['keyed_sole_min_y_m','keyed_sole_max_y_m','center_airborne_key_count_over_10mm','sole_penetrating_key_count_below_minus_5mm','segment_lengths_m']}for side,leg in v['legs'].items()}for k,v in report['variants'].items()},indent=2))
